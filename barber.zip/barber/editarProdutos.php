<?php
    require_once('conectar.php'); 

    $id = trim($_POST['id']); 
    $nom  = trim($_POST['txtNom']);
    $forn = trim($_POST['txtForn']); 
    $qtd = trim($_POST['txtQtd']);
    $val = trim($_POST['txtVal']);

    if(!empty($nom) && !empty($forn) && !empty($qtd) && !empty($val)){
      $conex=open_database(); 
      selectDb();
      $sql = "UPDATE produtos set nome_produto='$nom',
              fornecedor='$forn', qtd_produto='$qtd', valor_produto='$val' 
              where id='$id';";
      $ins = mysql_query($sql); 
      close_database($conex); 
      
      if ($ins==FALSE)
         $mensagem = "Erro: não foi possível atualizar os dados"; 
      else {
         $mensagem = "Foi alterado os seguintes" . mysql_affected_rows() . " dados <br/>";
         unset($id, $nom, $forn, $qtd, $val); 
      }
      echo $mensagem; 
    }
    header("location: listarProdutos.php")
?>