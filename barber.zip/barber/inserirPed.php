<?php
    require_once('conectar.php'); 

    $dat  = trim($_POST['txtDat']);
    $cliente = trim($_POST['txtCliente']); 
    $qtd = trim($_POST['txtQtd']);
    $val = trim($_POST['txtVal']);
    if(!empty($dat) && !empty($cliente) && !empty($qtd) && !empty($val)){
      $conex = open_database(); 
      selectDb();   
      $sql = "INSERT INTO produtos (data_pedido, nome_cliente_pedido, quantidade_pedido, valor_pedido) VALUES  ('$dat', '$cliente', '$qtd', '$val');";
      $ins = mysql_query($sql); 
      close_database($conex); 


      if ($ins==FALSE)
         $mensagem = "Consulta inserir pedidos deu erro..."; 
      else {
         $mensagem = "Foi inserido os seguintes" . mysql_affected_rows() . " dados <br/>";
         unset($dat, $cliente, $qtd, $val); 
      }
      echo $mensagem; 
    }
    header("location: listarpedidos.php")
?>