<?php
    require_once('conectar.php'); 

     $id = trim($_REQUEST['id']); 

     $conex = open_database(); 
     selectDb(); 
     $registros = mysql_query("SELECT * FROM pedido where id=". $id); 
     close_database($conex);

     $row = mysql_fetch_array($registros); 
     $nom = $row['data_pedido']; 
     $cpf = $row['nome_cliente_pedido']; 
     $end = $row['quantidade_pedido'];  
     $tel = $row['valor_pedido'];
?>
<!DOCTYPE html>
<html lang="pt-br">
     <head>
        <meta charset="UTF-8">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/style.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <title>Alterar Pedido da Barbearia</title>
    </head>
    <body background="back.jpg" class="container">
        <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="admin.html">Barbearia do Zé - Editar Pedidos</a>
          </div>
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
              <li class="active"><a href="admin.html"><span class="glyphicon glyphicon-home"></span> Início</a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-ok"></span> Cadastrar <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="inserirClientes.html"><span class="glyphicon glyphicon-user"></span> Cliente</a></li>
                  <li><a href="inserirProdutos.html"><span class="glyphicon glyphicon-barcode"></span> Produto</a></li>
                  <li><a href="inserirPedidos.html"><span class="glyphicon glyphicon-shopping-cart"></span> Pedido</a></li>
                </ul>
              </li>
              <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-th-list"></span> Listar <span class="caret"></span></a>
              <ul class="dropdown-menu">
                    <li><a href="listarClientes.php"><span class="glyphicon glyphicon-user"></span> Cliente</a></li>
                    <li><a href="listarProdutos.php"><span class="glyphicon glyphicon-barcode"></span> Produto</a></li>
                    <li><a href="listarPedidos.php"><span class="glyphicon glyphicon-shopping-cart"></span> Pedido</a></li>
              </ul>
            </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sair</a></li>
            </ul>
          </div>
        </div>
        </nav>
        <h1>Alteração de dados do Pedido</h1>
        <form id="frmEditarClientes" name="frmEditarClientes" method="post" action="editarClientes.php">
           <div class="form-group">
              <label for="lblIdt">ID: <?php echo $id?> </label>
              <input type="hidden" name="id" value="<?php echo $id?>"/>
           </div>
           <div class="form-group">
              <label for="lblNom">Data do Pedido:</label>
              <input type="text" class="form-control" id="txtNom"
               name="txtNom" value="<?php echo $nom?>" placeholder="Data do Pedido">
           </div>
           <div class="form-group">
              <label for="lblCPF">Nome do Cliente:</label>
              <input type="text" class="form-control" id="txtCPF" 
              name="txtCPF" value="<?php echo $cpf?>" placeholder="Cliente">
           </div>
           <div class="form-group">
              <label for="lblEnd">Quantidade do Pedido:</label>
              <input type="text" class="form-control" name="txtEnd" 
              id="txtEnd" value="<?php echo $end?>" placeholder="Quantidade">
           </div>
           <div class="form-group">
              <label for="lblTel">Valor Total dos Pedidos:</label>
              <input type="text" class="form-control" name="txtTel" 
              id="txtTel" value="<?php echo $tel?>" placeholder="R$">
           </div>         
           <input name="bt_ed" id="bt_ed" class="btn btn-success" type="submit" value="Salvar"> 
           <input name="bt_voltar" id="bt_voltar" class="btn btn-danger" type="button" value="Ver Todos os Pedidos"
                 onclick="javascript:location.href='listarClientes.php'"> 

        </form>
    </body>   
</html>



