<?php 
  echo "Fema@2017: " . md5("Fema@2017");
  echo "<BR/><br/>"; 
  echo "Imesa@2017: " . md5("Imesa@2017");
  echo "<BR/><br/>"; 
  echo "João Tasquin: " . md5("João Tasquin");
?>