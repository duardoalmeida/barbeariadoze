<?php
$usuario = trim($_POST['username']);
$senha = trim($_POST['password']);
$pwdmd5 = md5($pswd); 
require_once "conectar.php";
$conex = open_database();
selectDb();
$sql = "SELECT * FROM usuarios where usuario like '$usuario'";
$rs = mysql_query($sql);
close_database($conex);
$row = mysql_fetch_array($rs);
echo $row['usuario'] . " -  " . $row['senha'] . "<BR/><br/>";
if(md5($senha) == $row['senha']){
     session_start(); //INICIALIZA A SESSÃO 
    //GRAVA AS VARIÁVEIS NA SESSÃO 
     $_SESSION['user'] = $usuario; 
    // $_SESSION['pswd'] = $pswd;
    Header("Location: listarProdutos.php"); //REDIRECIONA PARA A PÁGINA QUE VAI EXIBIR OS PRODUTOS
}
else Header("Location: admin.html");
?>
