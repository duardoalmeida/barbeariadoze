<?php
    require_once('conectar.php'); 

    $nom  = trim($_POST['txtNom']);
    $forn = trim($_POST['txtforn']); 
    $qtd = trim($_POST['txtQtd']);
    $val = trim($_POST['txtVal']);
    if(!empty($nom) && !empty($forn) && !empty($qtd) && !empty($val)){
      $conex = open_database(); 
      selectDb();   
      $sql = "INSERT INTO produtos (nome_produto, fornecedor, qtd_produto, valor_produto) VALUES  ('$nom', '$forn', '$qtd', '$val');";
      $ins = mysql_query($sql); 
      close_database($conex); 


      if ($ins==FALSE)
         $mensagem = "Consulta inserir produtos deu erro..."; 
      else {
         $mensagem = "Foi inserido os seguintes" . mysql_affected_rows() . " dados <br/>";
         unset($nom, $forn, $qtd, $val); 
      }
      echo $mensagem; 
    }
    header("location: listarProdutos.php")
?>